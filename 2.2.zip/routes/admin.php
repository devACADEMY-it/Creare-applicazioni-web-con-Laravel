<?php

Route::get('/', function() {
    return '<h1>Admin Panel</h1>';
});
