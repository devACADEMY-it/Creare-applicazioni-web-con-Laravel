<?php

use Illuminate\Support\Facades\Route;

// localhost:8000/blog
Route::get('/', function () {
    return '<h1>Blog</h1>';
});

// localhost:8000/blog/{slug}/{user}
Route::get('/{slug}/{user?}', function ($slug, $user = 'user') {
    return '<h1>'.$slug.'</h1><h2>'.$user.'</h2>';
})->where('slug', '[a-zA-Z\-]+')->where('user', '[a-zA-Z]+');

