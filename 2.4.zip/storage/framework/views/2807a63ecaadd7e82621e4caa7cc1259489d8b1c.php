<h1>Users</h1>
<?php /**PATH /Users/macbookadriano/code/blog/resources/views/users.blade.php ENDPATH**/ ?>