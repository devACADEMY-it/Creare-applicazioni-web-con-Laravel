<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController as HomeController;

Route::get('/', [HomeController::class, 'home']);

Route::get('/users', function () {
    return view('users');
});
