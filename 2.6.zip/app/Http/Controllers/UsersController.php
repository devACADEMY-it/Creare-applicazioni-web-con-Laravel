<?php

namespace App\Http\Controllers;

class UsersController extends Controller {
    public function users() {
        return view('users');
    }
}
