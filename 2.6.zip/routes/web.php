<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{HomeController, UsersController};

Route::get('/', [HomeController::class, 'home']);

Route::get('/users', [UsersController::class, 'users']);
