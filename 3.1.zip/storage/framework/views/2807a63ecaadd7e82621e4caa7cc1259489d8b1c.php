<h1>Ciao utenti</h1>
<?php /**PATH /Users/macbookadriano/code/blog/resources/views/users.blade.php ENDPATH**/ ?>