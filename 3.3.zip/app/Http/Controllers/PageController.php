<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller {
    protected $data = [
        [
            'name' => 'UX/UI Design',
            'desc' => 'Testo di prova'
        ],
        [
            'name' => 'Web App',
            'desc' => 'Testo di prova'
        ],
        [
            'name' => 'Mobile App',
            'desc' => 'Testo di prova'
        ]
    ];

    public function index() {
        return view('homepage');
    }

    public function about() {
        return view('about');
    }

    public function services() {
        return view('services', [ 'title' => 'Our services', 'services' => $this->data ]);
    }
}
