<h1><?=$title?></h1>

<ul>
<?php
    if (!empty($services)) {
        foreach($services as $service) {
            echo '<li>'.$service["name"].'</li>';
        }
    }
?>
<ul>
