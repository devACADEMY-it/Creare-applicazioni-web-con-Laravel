<h1>{{ $title }}</h1>

<ul>
    @if (!empty($services))
        @foreach($services as $service)
            <li>{{ $service["name"] }}</li>
        @endforeach
    @endif
<ul>
