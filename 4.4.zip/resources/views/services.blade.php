@extends('layouts.base')

@section('title', $title)

@section('mainContent')
<h1>I Nostri Servizi</h1>

@foreach($services as $service)
    @component('components/card', [
        'img_url' => 'https://via.placeholder.com/150',
        'img_alt' => 'Testo di esempio',
        'title' => $service['name'],
        'desc' => $service['desc']
    ])
@endforeach
@endsection
