<div class="card" style="width: 18rem;">
    <img class="card-img-top" src="{{$imgUrl}}">
    <div class="card-body">
        <h5 class="card-title">{{$title}}</h5>
        <p class="card-text">{{$desc}}</p>
        <a href="#" class="btn btn-primary">Scopri di più</a>
    </div>
</div>
