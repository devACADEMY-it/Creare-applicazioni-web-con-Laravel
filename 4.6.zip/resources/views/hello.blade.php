<x-welcome :name='$name'></x-welcome>
