<?php

use App\Http\Controllers\{PageController};
use Illuminate\Support\Facades\Request;

Route::get('/', [PageController::class, 'index']);
Route::view('/welcome', 'hello', ['name' => Request::input('name')]);
Route::get('/about', [PageController::class, 'about']);
Route::get('/services', [PageController::class, 'services']);
