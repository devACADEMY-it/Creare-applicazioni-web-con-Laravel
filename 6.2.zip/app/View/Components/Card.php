<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Card extends Component
{
    public $imgUrl;
    public $title;
    public $desc;

    /**
     * Create a new component instance.
     *
     * @return void
     */
    public function __construct($imgUrl = '', $title = '', $desc = '')
    {
        $this->imgUrl = $imgUrl;
        $this->title = $title;
        $this->desc = $desc;
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|string
     */
    public function render()
    {
        return view('components.card');
    }
}
