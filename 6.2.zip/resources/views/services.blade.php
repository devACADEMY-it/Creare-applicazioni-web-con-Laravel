@extends('layouts.base')

@section('title', $title)

@section('mainContent')
<h1>I Nostri Servizi</h1>

@foreach($services as $service)
    <x-card
        img-url="https://via.placeholder.com/150"
        :title="$service['name']"
        :desc="$service['desc']"
    />
@endforeach
@endsection
