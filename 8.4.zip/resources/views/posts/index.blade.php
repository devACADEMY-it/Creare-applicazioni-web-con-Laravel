@extends('layouts/base')

@section('title', 'Homepage - Carmhack Blog')

@section('content')
    @foreach($posts as $post)
        @include('partials.summary')
    @endforeach
@endsection
