@extends('layouts.base')

@section('title', $post->title)

@section('content')
    @include('partials.summary')
@endsection
