@extends('layouts.base')

@section('title', $post->title)

@section('content')
    @include('partials.summary')

    <form method="post" action="{{ route('posts.destroy', [$post->slug]) }}">
        @csrf
        @method('delete')

        <div class="field is-grouped">
          <div class="control">
            <a
              href="{{ route('posts.edit', [$post->slug])}}"
              class="button is-info is-outlined"
            >
              Modifica
            </a>
          </div>
          <div class="control">
            <button type="submit" class="button is-danger is-outlined">
              Elimina
            </button>
          </div>
        </div>
    </form>
@endsection
