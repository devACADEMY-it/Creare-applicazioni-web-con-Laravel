<div class="content">
  <a href="{{ route('posts.show', [$post->slug]) }}">
    <h1 class="title">{{ $post->title }}</h1>
  </a>
  <p><strong>Creato il</strong> {{ $post->created_at->diffForHumans() }}</p>
  <p>{!! nl2br(e($post->content)) !!}</p>
</div>
