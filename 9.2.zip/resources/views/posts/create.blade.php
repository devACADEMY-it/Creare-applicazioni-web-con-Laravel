@extends('layouts.base')

@section('title', 'Crea nuovo post - Carmhack Blog')

@section('content')
<h1 class="title">Crea nuovo post</h1>

<form method="post" action="{{ route('posts.store') }}">
    @csrf
    @include('partials.errors')

    <div class="field">
        <label class="label">Titolo</label>
        <div class="control">
            <input type="text" name="title" value="{{ old('title') }}" class="input" placeholder="Titolo" minlength="5" maxlength="100" required />
        </div>
    </div>

    <div class="field">
        <label class="label">Contenuto</label>
        <div class="control">
            <textarea
                name="content"
                class="textarea"
                placeholder="Content"
                minlength="5"
                maxlength="2000"
                required rows="10"
            >{{ old('content') }}</textarea>
        </div>
    </div>

    <div class="field">
        <div class="control">
            <button type="submit" class="button is-link is-outlined">Pubblica</button>
        </div>
    </div>
</form>

@endsection
