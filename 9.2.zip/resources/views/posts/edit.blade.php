@extends('layouts.base')

@section('title', 'Modifica post')

@section('content')
<h1 class="title">Modifica: {{ $post->title }}</h1>

<form method="post" action="{{ route('posts.update', [$post->slug]) }}">
    @csrf
    @method('patch')
    @include('partials.errors')

    <div class="field">
        <label class="label">Titolo</label>
        <div class="control">
            <input type="text" name="title" value="{{ $post->title }}" class="input" placeholder="Title" minlength="5" maxlength="100" required />
        </div>
    </div>

    <div class="field">
        <label class="label">Contenuto</label>
        <div class="control">
            <textarea name="content" class="textarea" placeholder="Content" minlength="5" maxlength="2000" required rows="10">
                {{ $post->content }}
            </textarea>
        </div>
    </div>

    <div class="field">
        <div class="control">
            <button type="submit" class="button is-link is-outlined">Aggiorna</button>
        </div>
    </div>
</form>
@endsection
